#!/bin/tcsh
../make-inset-figure.py --svg='Gv_HMP9231.svg' \
--full_area='100,100,3000,3000' \
--inset_area='1475,350,575,575' \
--output_height=1000 \
--output_prefix=Gv_HMP9231-inset-1
