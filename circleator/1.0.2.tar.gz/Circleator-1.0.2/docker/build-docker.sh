#!/bin/bash

docker build -t umigs/circleator-v1.0.2 .
